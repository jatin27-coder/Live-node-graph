$ErrorActionPreference = "Stop"

Write-Host "=== Live Node Graph setup for Windows ===" -ForegroundColor Cyan

$projectRoot = "C:\Users\dwijh\OneDrive\Desktop\live-node-graph\live-node-graph"
$frontendDir = Join-Path $projectRoot "frontend"
$apiDir = Join-Path $projectRoot "api"
$simDir = Join-Path $projectRoot "simulator"

if (-not (Test-Path $projectRoot)) {
    throw "Project folder not found: $projectRoot"
}

Write-Host "Checking required tools..." -ForegroundColor Yellow
$required = @(
    @{ Name = "node"; Command = "node"; Args = "-v" },
    @{ Name = "npm"; Command = "npm"; Args = "-v" },
    @{ Name = "python"; Command = "python"; Args = "--version" },
    @{ Name = "pip"; Command = "pip"; Args = "--version" }
)

foreach ($item in $required) {
    $cmd = Get-Command $item.Command -ErrorAction SilentlyContinue
    if (-not $cmd) {
        throw "Missing required tool: $($item.Name). Install it first and rerun this script."
    }
}

Write-Host "Setting PowerShell execution policy for user..." -ForegroundColor Yellow
try {
    Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned -Force
} catch {
    Write-Host "Could not change execution policy automatically. Continuing..." -ForegroundColor Yellow
}

$ngspice = Get-Command ngspice -ErrorAction SilentlyContinue
if (-not $ngspice) {
    Write-Host "ngspice was not found on PATH. Install it before running the simulator." -ForegroundColor Red
    Write-Host "You can continue with frontend/api setup, but the simulator will fail until ngspice is installed." -ForegroundColor Yellow
}

Write-Host "Installing frontend dependencies..." -ForegroundColor Yellow
Set-Location $frontendDir
npm install

Write-Host "Installing API dependencies..." -ForegroundColor Yellow
Set-Location $apiDir
npm install

Write-Host "Creating Python virtual environment for simulator..." -ForegroundColor Yellow
Set-Location $simDir
if (-not (Test-Path ".venv")) {
    python -m venv .venv
}

& ".\.venv\Scripts\Activate.ps1"
pip install -r requirements.txt

Write-Host "Setup complete." -ForegroundColor Green
Write-Host "" 
Write-Host "Run these in separate terminals:" -ForegroundColor Cyan
Write-Host "1) Frontend:" -ForegroundColor Cyan
Write-Host "   cd `"$frontendDir`"; npm run dev" -ForegroundColor White
Write-Host "2) API:" -ForegroundColor Cyan
Write-Host "   cd `"$apiDir`"; `$env:MONGO_URL='mongodb://localhost:27017'; `$env:SIMULATOR_URL='http://localhost:8000'; `$env:SIMULATOR_TIMEOUT_MS='8000'; npm start" -ForegroundColor White
Write-Host "3) Simulator:" -ForegroundColor Cyan
Write-Host "   cd `"$simDir`"; .\.venv\Scripts\Activate.ps1; uvicorn app.main:app --host 0.0.0.0 --port 8000" -ForegroundColor White
Write-Host "4) MongoDB (optional if using Docker Compose):" -ForegroundColor Cyan
Write-Host "   docker run -d --name mongo -p 27017:27017 mongo:7" -ForegroundColor White
Write-Host "" 
Write-Host "Open the frontend at: http://localhost:5173" -ForegroundColor Green
