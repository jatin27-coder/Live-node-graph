import { useCallback, useEffect, useMemo, useRef, useState, type DragEvent } from 'react';
import {
  Background,
  Controls,
  MiniMap,
  ReactFlow,
  ReactFlowProvider,
  addEdge,
  reconnectEdge,
  useEdgesState,
  useNodesState,
  useReactFlow,
  type Connection,
  type Edge,
  type Node,
  type NodeTypes,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { loadGraph, saveGraph } from './api';
import { GraphNode } from './GraphNode';
import { DRAG_MIME, Palette } from './Palette';
import { SimContext } from './simContext';
import { Toolbar } from './Toolbar';
import { NODE_SPECS, NODE_TYPE_KEYS, OUTPUT_HANDLE } from './nodeRegistry';
import { useLiveSimulation } from './useLiveSimulation';

const nodeTypes = Object.fromEntries(NODE_TYPE_KEYS.map((t) => [t, GraphNode])) as unknown as NodeTypes;

const newId = (type: string) => `${type}-${Math.random().toString(36).slice(2, 8)}`;
const makeNode = (type: string, position: { x: number; y: number }, id = newId(type)): Node => ({
  id,
  type,
  position,
  data: { ...NODE_SPECS[type].defaults },
});

// A small starting graph so the first screen already shows something live: 2 + 3 -> Display.
const starterNodes: Node[] = [
  { ...makeNode('number', { x: 40, y: 40 }, 'start-a'), data: { value: '2' } },
  { ...makeNode('number', { x: 40, y: 190 }, 'start-b'), data: { value: '3' } },
  makeNode('add', { x: 300, y: 100 }, 'start-add'),
  makeNode('display', { x: 540, y: 110 }, 'start-out'),
];
const starterEdges: Edge[] = [
  { id: 'e1', source: 'start-a', sourceHandle: OUTPUT_HANDLE, target: 'start-add', targetHandle: 'a' },
  { id: 'e2', source: 'start-b', sourceHandle: OUTPUT_HANDLE, target: 'start-add', targetHandle: 'b' },
  { id: 'e3', source: 'start-add', sourceHandle: OUTPUT_HANDLE, target: 'start-out', targetHandle: 'x' },
];

function Editor() {
  const [nodes, setNodes, onNodesChange] = useNodesState<Node>(starterNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState<Edge>(starterEdges);
  const { screenToFlowPosition, fitView } = useReactFlow();
  const sim = useLiveSimulation(nodes, edges);
  const reconnecting = useRef<string | null>(null);
  const [count, setCount] = useState(0);

  // Wiring rules: output -> input only, never to itself, one wire per input.
  // (An output may feed many inputs. The edge currently being dragged does not count as occupying its input.)
  const isValidConnection = useCallback(
    (c: Connection | Edge) =>
      c.source !== c.target &&
      c.sourceHandle === OUTPUT_HANDLE &&
      !!c.targetHandle &&
      !edges.some((e) => e.id !== reconnecting.current && e.target === c.target && e.targetHandle === c.targetHandle),
    [edges],
  );

  const onConnect = useCallback(
    (c: Connection) => isValidConnection(c) && setEdges((eds) => addEdge(c, eds)),
    [isValidConnection, setEdges],
  );

  const addNode = useCallback(
    (type: string, position?: { x: number; y: number }) => {
      const at = position ?? { x: 120 + (count % 6) * 30, y: 80 + (count % 6) * 30 };
      setCount((n) => n + 1);
      setNodes((ns) => [...ns, makeNode(type, at)]);
    },
    [count, setNodes],
  );

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    const type = e.dataTransfer.getData(DRAG_MIME);
    if (type in NODE_SPECS) addNode(type, screenToFlowPosition({ x: e.clientX, y: e.clientY }));
  };

  const removeSelectedNodes = useCallback(() => {
    const selectedIds = new Set(nodes.filter((node) => node.selected).map((node) => node.id));
    if (selectedIds.size === 0) return;

    setNodes((current) => current.filter((node) => !selectedIds.has(node.id)));
    setEdges((current) => current.filter((edge) => !selectedIds.has(edge.source) && !selectedIds.has(edge.target)));
  }, [nodes, setEdges, setNodes]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const isTypingField = !!target && (
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.tagName === 'SELECT' ||
        target.isContentEditable
      );

      if ((event.key === 'Delete' || event.key === 'Backspace') && !isTypingField) {
        const selectedIds = new Set(nodes.filter((node) => node.selected).map((node) => node.id));
        if (selectedIds.size > 0) {
          event.preventDefault();
          removeSelectedNodes();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nodes, removeSelectedNodes]);

  const clearGraph = useCallback(() => {
    if (nodes.length === 0) return;
    const confirmed = window.confirm('Delete all nodes and connections?');
    if (!confirmed) return;
    setNodes([]);
    setEdges([]);
  }, [nodes.length, setEdges, setNodes]);

  const save = async (name: string) => {
    await saveGraph(name, {
      nodes: nodes.map((n) => ({
        id: n.id,
        type: n.type ?? '',
        position: n.position,
        data: n.data as Record<string, string>,
      })),
      edges: edges.map((e) => ({
        id: e.id,
        source: e.source,
        target: e.target,
        sourceHandle: e.sourceHandle ?? null,
        targetHandle: e.targetHandle ?? null,
      })),
    });
  };

  const load = async (name: string) => {
    const doc = await loadGraph(name);
    setNodes(doc.nodes.map((n) => ({ id: n.id, type: n.type, position: n.position, data: n.data })));
    setEdges(
      doc.edges.map((e) => ({
        id: e.id ?? `${e.source}-${e.target}-${e.targetHandle}`,
        source: e.source,
        target: e.target,
        sourceHandle: e.sourceHandle,
        targetHandle: e.targetHandle,
      })),
    );
    setTimeout(() => fitView({ padding: 0.2 }), 50);
  };

  // Wires leaving a node that is not "ok" are drawn dashed so the problem is visible on the wire too.
  const shownEdges = useMemo(
    () =>
      edges.map((e) => {
        const r = sim.results[e.source];
        return r && r.status !== 'ok' ? { ...e, className: 'wire-broken', animated: false } : { ...e, animated: sim.phase === 'ready' && !!r };
      }),
    [edges, sim],
  );

  return (
    <SimContext.Provider value={sim}>
      <div className="app">
        <Toolbar
          sim={sim}
          selectedCount={nodes.filter((node) => node.selected).length}
          onSave={save}
          onLoad={load}
          onClear={clearGraph}
          onRemoveSelected={removeSelectedNodes}
        />
        <div className="main">
          <Palette onAdd={(t) => addNode(t)} />
          <div className="canvas" onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; }} onDrop={onDrop}>
            <ReactFlow
              nodes={nodes}
              edges={shownEdges}
              nodeTypes={nodeTypes}
              onNodesChange={onNodesChange}
              onEdgesChange={onEdgesChange}
              onConnect={onConnect}
              isValidConnection={isValidConnection}
              onReconnectStart={(_, edge) => { reconnecting.current = edge.id; }}
              onReconnect={(oldEdge, c) => setEdges((eds) => reconnectEdge(oldEdge, c, eds))}
              onReconnectEnd={(_, edge, _type, state) => {
                reconnecting.current = null;
                // dropped on empty canvas: remove the wire, like unplugging a cable
                if (!state.isValid) setEdges((eds) => eds.filter((e) => e.id !== edge.id));
              }}
              colorMode="light"
              style={{ background: '#f5f8ff' }}
              fitView
              proOptions={{ hideAttribution: true }}
            >
              <Background color="#dfe9f8" gap={18} size={1} />
              <Controls />
              <MiniMap pannable zoomable />
            </ReactFlow>
          </div>
        </div>
      </div>
    </SimContext.Provider>
  );
}

export default function App() {
  return (
    <ReactFlowProvider>
      <Editor />
    </ReactFlowProvider>
  );
}
