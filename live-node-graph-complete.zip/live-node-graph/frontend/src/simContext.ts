import { createContext } from 'react';
import type { SimView } from './useLiveSimulation';

export const SimContext = createContext<SimView>({ phase: 'pending', results: {}, status: { phase: 'idle' } });
