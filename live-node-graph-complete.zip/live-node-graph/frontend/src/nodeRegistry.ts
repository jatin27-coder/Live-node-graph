// Frontend description of every node type. The palette, the node component and the default
// data are all generated from this table. To add a node type, add an entry here and a matching
// NodeSpec in simulator/app/registry.py.

export interface NodeSpec {
  label: string;
  hint: string;
  inputs: string[]; // handle ids, top to bottom
  hasOutput: boolean;
  defaults: Record<string, string>;
}

export const NODE_SPECS: Record<string, NodeSpec> = {
  number: { label: 'Number', hint: 'a constant', inputs: [], hasOutput: true, defaults: { value: '0' } },
  add: { label: 'Add', hint: 'a + b', inputs: ['a', 'b'], hasOutput: true, defaults: {} },
  multiply: { label: 'Multiply', hint: 'a × b', inputs: ['a', 'b'], hasOutput: true, defaults: {} },
  divide: { label: 'Divide', hint: 'a ÷ b', inputs: ['a', 'b'], hasOutput: true, defaults: {} },
  formula: { label: 'Formula', hint: 'your expression', inputs: ['a', 'b'], hasOutput: true, defaults: { expr: 'a * 2 + b' } },
  display: { label: 'Display', hint: 'shows a value', inputs: ['x'], hasOutput: false, defaults: {} },
};

export const OUTPUT_HANDLE = 'out';
export const NODE_TYPE_KEYS = Object.keys(NODE_SPECS);
