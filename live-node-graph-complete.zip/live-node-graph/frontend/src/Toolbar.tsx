import { useEffect, useState } from 'react';
import { listGraphs } from './api';
import type { SimView } from './useLiveSimulation';

interface Props {
  sim: SimView;
  selectedCount: number;
  onSave: (name: string) => Promise<void>;
  onLoad: (name: string) => Promise<void>;
  onDeleteSaved: (name: string) => Promise<void>;
  onClear: () => void;
  onRemoveSelected: () => void;
}

function statusText(sim: SimView): { text: string; tone: 'ok' | 'busy' | 'bad' } {
  const s = sim.status;
  if (s.phase === 'unavailable') {
    const retry = s.retryInMs === null ? '' : ` Retrying in ${Math.ceil(s.retryInMs / 1000)}s…`;
    return { text: `${s.message}${retry}`, tone: 'bad' };
  }
  if (sim.phase === 'ready') return { text: 'Live · in sync', tone: 'ok' };
  return { text: 'Computing…', tone: 'busy' };
}

export function Toolbar({ sim, selectedCount, onSave, onLoad, onDeleteSaved, onClear, onRemoveSelected }: Props) {
  const [name, setName] = useState('my-graph');
  const [saved, setSaved] = useState<string[]>([]);
  const [selectedSaved, setSelectedSaved] = useState('');
  const [notice, setNotice] = useState<{ text: string; tone: 'success' | 'error' } | null>(null);

  const refresh = () => listGraphs().then((g) => setSaved(g.map((x) => x.name)), () => setSaved([]));
  useEffect(() => void refresh(), []);

  useEffect(() => {
    if (!notice) return;
    const timeout = window.setTimeout(() => setNotice(null), 4000);
    return () => window.clearTimeout(timeout);
  }, [notice]);

  const run = async (label: string, fn: () => Promise<void>) => {
    try {
      await fn();
      setNotice({ text: label, tone: 'success' });
      await refresh();
    } catch (err) {
      setNotice({ text: err instanceof Error ? err.message : 'Something went wrong.', tone: 'error' });
    }
  };

  const deleteSelectedSaved = () => {
    if (!selectedSaved || !window.confirm(`Delete saved graph “${selectedSaved}”? This cannot be undone.`)) return;
    const deletedName = selectedSaved;
    void run(`Deleted “${deletedName}”`, async () => {
      await onDeleteSaved(deletedName);
      setSelectedSaved('');
    });
  };

  const { text, tone } = statusText(sim);
  return (
    <header className="toolbar">
      <div className="toolbar-left">
        <div className="brand">
          <span className="brand-mark">LN</span>
          <span>Live Node Graph</span>
        </div>
      </div>

      <div className="toolbar-controls">
        <input className="name" aria-label="graph name" value={name} onChange={(e) => setName(e.target.value)} />
        <button onClick={() => run(`Saved “${name}”`, () => onSave(name))}>Save</button>
        <select aria-label="saved graphs" value={selectedSaved} onChange={(e) => {
          const selectedName = e.target.value;
          setSelectedSaved(selectedName);
          if (selectedName) {
            setName(selectedName);
            void run(`Loaded “${selectedName}”`, () => onLoad(selectedName));
          }
        }}>
          <option value="">Load…</option>
          {saved.map((n) => (
            <option key={n} value={n}>{n}</option>
          ))}
        </select>
        <button className="ghost danger" onClick={deleteSelectedSaved} disabled={!selectedSaved}>Delete Saved</button>
        <button className="ghost danger" onClick={onRemoveSelected} disabled={selectedCount === 0}>Remove Selected</button>
        <button className="ghost" onClick={onClear}>Clear</button>
      </div>

      <div className="toolbar-meta">
        <span className={`pill tone-${tone}`} role="status" aria-live="polite">{text}</span>
      </div>
      {notice && (
        <div className={`toast toast-${notice.tone}`} role={notice.tone === 'error' ? 'alert' : 'status'} aria-live={notice.tone === 'error' ? 'assertive' : 'polite'}>
          {notice.text}
        </div>
      )}
    </header>
  );
}
