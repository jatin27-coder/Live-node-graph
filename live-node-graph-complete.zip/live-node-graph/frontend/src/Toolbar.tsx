import { useEffect, useState } from 'react';
import { listGraphs } from './api';
import type { SimView } from './useLiveSimulation';

interface Props {
  sim: SimView;
  selectedCount: number;
  onSave: (name: string) => Promise<void>;
  onLoad: (name: string) => Promise<void>;
  onClear: () => void;
  onRemoveSelected: () => void;
}

function statusText(sim: SimView): { text: string; tone: 'ok' | 'busy' | 'bad' } {
  const s = sim.status;
  if (s.phase === 'unavailable') {
    const retry = s.retryInMs === null ? '' : ` Retrying in ${Math.ceil(s.retryInMs / 1000)}s…`;
    return { text: `${s.message}${retry}`, tone: 'bad' };
  }
  if (sim.phase === 'ready') return { text: 'Live · in sync', tone: 'ok' };
  return { text: 'Computing…', tone: 'busy' };
}

export function Toolbar({ sim, selectedCount, onSave, onLoad, onClear, onRemoveSelected }: Props) {
  const [name, setName] = useState('my-graph');
  const [saved, setSaved] = useState<string[]>([]);
  const [message, setMessage] = useState('');

  const refresh = () => listGraphs().then((g) => setSaved(g.map((x) => x.name)), () => setSaved([]));
  useEffect(() => void refresh(), []);

  const run = async (label: string, fn: () => Promise<void>) => {
    try {
      await fn();
      setMessage(label);
      await refresh();
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Something went wrong.');
    }
  };

  const { text, tone } = statusText(sim);
  return (
    <header className="toolbar">
      <div className="toolbar-left">
        <div className="brand">
          <span className="brand-mark">LN</span>
          <span>Live Node Graph</span>
        </div>
      </div>

      <div className="toolbar-controls">
        <input className="name" aria-label="graph name" value={name} onChange={(e) => setName(e.target.value)} />
        <button onClick={() => run(`Saved “${name}”`, () => onSave(name))}>Save</button>
        <select aria-label="saved graphs" value="" onChange={(e) => e.target.value && (setName(e.target.value), run(`Loaded “${e.target.value}”`, () => onLoad(e.target.value)))}>
          <option value="">Load…</option>
          {saved.map((n) => (
            <option key={n} value={n}>{n}</option>
          ))}
        </select>
        <button className="ghost danger" onClick={onRemoveSelected} disabled={selectedCount === 0}>Remove Selected</button>
        <button className="ghost" onClick={onClear}>Clear</button>
      </div>

      <div className="toolbar-meta">
        <span className="flash" role="status">{message}</span>
        <span className={`pill tone-${tone}`} role="status" aria-live="polite">{text}</span>
      </div>
    </header>
  );
}
