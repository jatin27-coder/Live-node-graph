import type { GraphPayload, NodeResult, Outcome } from './liveSync';

export interface SavedGraph {
  name: string;
  updatedAt: string;
  nodes: { id: string; type: string; position: { x: number; y: number }; data: Record<string, string> }[];
  edges: { id?: string; source: string; target: string; sourceHandle: string | null; targetHandle: string | null }[];
}

async function readError(res: Response): Promise<{ code: string; message: string }> {
  try {
    const body = await res.json();
    if (body?.error) return { code: body.error.code ?? 'error', message: body.error.message ?? 'Request failed.' };
  } catch {
    /* not JSON (e.g. a proxy error page) */
  }
  return { code: res.status === 502 || res.status === 503 || res.status === 504 ? 'simulator_unavailable' : 'error', message: `Server answered ${res.status}.` };
}

/** One simulation round-trip. Never throws for HTTP-level problems; returns a typed outcome. */
export async function simulate(graph: GraphPayload, revision: number, signal: AbortSignal): Promise<Outcome> {
  const res = await fetch('/api/simulate', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ ...graph, revision }),
    signal,
  });
  if (!res.ok) return { ok: false, ...(await readError(res)) };
  const body = (await res.json()) as { revision: number | string | null; nodes: Record<string, NodeResult> };
  return { ok: true, revision: body.revision, nodes: body.nodes };
}

async function json<T>(res: Response): Promise<T> {
  if (!res.ok) throw new Error((await readError(res)).message);
  return (await res.json()) as T;
}

export const listGraphs = () => fetch('/api/graphs').then((r) => json<{ name: string; updatedAt: string }[]>(r));
export const loadGraph = (name: string) => fetch(`/api/graphs/${encodeURIComponent(name)}`).then((r) => json<SavedGraph>(r));
export const deleteGraph = (name: string) =>
  fetch(`/api/graphs/${encodeURIComponent(name)}`, { method: 'DELETE' }).then((r) => json<{ name: string; deleted: boolean }>(r));
export const saveGraph = (name: string, graph: Pick<SavedGraph, 'nodes' | 'edges'>) =>
  fetch(`/api/graphs/${encodeURIComponent(name)}`, {
    method: 'PUT',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(graph),
  }).then((r) => json<{ name: string; updatedAt: string }>(r));
