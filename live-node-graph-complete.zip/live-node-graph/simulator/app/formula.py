"""Safe parser for Formula-node expressions.

The user-typed expression ends up inside a netlist that ngspice executes, so it is
never pasted through. We tokenise against a strict whitelist (numbers, ``a``, ``b``,
``+ - * /`` and brackets), build an AST, and re-serialise the AST ourselves. Anything
the grammar does not accept is rejected with a message pointing at the offending
character.
"""
from __future__ import annotations

import math
import re
from typing import Iterator

MAX_LENGTH = 200
MAX_DEPTH = 40
VARIABLES = ("a", "b")

_TOKEN = re.compile(r"[ \t]*(?:(?P<num>\d+\.?\d*|\.\d+)|(?P<var>[ab])|(?P<op>[-+*/()]))")

Ast = tuple  # ('num', float) | ('var', name) | ('neg', Ast) | ('bin', op, Ast, Ast)


class FormulaError(ValueError):
    """The expression is not allowed or not well formed."""


def _tokens(text: str) -> Iterator[tuple[str, str]]:
    pos = 0
    while True:
        # trailing spaces/tabs are fine; any other leftover character is not
        tail = text[pos:]
        if tail.strip(" \t") == "":
            return
        m = _TOKEN.match(text, pos)
        if not m:
            bad = tail.lstrip(" \t")[0]
            shown = repr(bad) if not bad.isprintable() or bad in "\n\r" else bad
            raise FormulaError(
                f"character {shown} is not allowed; use only numbers, a, b, + - * / and ( )"
            )
        pos = m.end()
        yield m.lastgroup, m.group(m.lastgroup)  # type: ignore[arg-type]


class _Parser:
    def __init__(self, text: str):
        self.toks = list(_tokens(text))
        self.i = 0

    def peek(self) -> tuple[str, str] | None:
        return self.toks[self.i] if self.i < len(self.toks) else None

    def take(self) -> tuple[str, str]:
        tok = self.peek()
        if tok is None:
            raise FormulaError("expression ends unexpectedly")
        self.i += 1
        return tok

    def parse(self) -> Ast:
        if not self.toks:
            raise FormulaError("expression is empty")
        node = self.expr(0)
        if self.peek() is not None:
            raise FormulaError(f"unexpected '{self.peek()[1]}'")
        return node

    def expr(self, depth: int) -> Ast:
        node = self.term(depth)
        while (t := self.peek()) and t[1] in "+-" and t[0] == "op":
            self.take()
            node = ("bin", t[1], node, self.term(depth))
        return node

    def term(self, depth: int) -> Ast:
        node = self.unary(depth)
        while (t := self.peek()) and t[1] in "*/" and t[0] == "op":
            self.take()
            node = ("bin", t[1], node, self.unary(depth))
        return node

    def unary(self, depth: int) -> Ast:
        if depth > MAX_DEPTH:
            raise FormulaError("expression is nested too deeply")
        t = self.peek()
        if t and t[0] == "op" and t[1] in "+-":
            self.take()
            inner = self.unary(depth + 1)
            return ("neg", inner) if t[1] == "-" else inner
        return self.primary(depth)

    def primary(self, depth: int) -> Ast:
        kind, text = self.take()
        if kind == "num":
            value = float(text)
            if not math.isfinite(value):
                raise FormulaError(f"number {text} is too large")
            return ("num", value)
        if kind == "var":
            return ("var", text)
        if text == "(":
            node = self.expr(depth + 1)
            closing = self.peek()
            if not closing or closing[1] != ")":
                raise FormulaError("missing closing bracket")
            self.take()
            return node
        raise FormulaError(f"unexpected '{text}'")


def parse(text: object) -> Ast:
    """Parse ``text`` into an AST or raise :class:`FormulaError`."""
    if not isinstance(text, str):
        raise FormulaError("expression must be text")
    if len(text) > MAX_LENGTH:
        raise FormulaError(f"expression is longer than {MAX_LENGTH} characters")
    return _Parser(text).parse()


def to_spice(ast: Ast, nets: dict[str, str]) -> str:
    """Serialise the AST as an ngspice expression; variables become V(<net>)."""
    kind = ast[0]
    if kind == "num":
        return repr(ast[1])
    if kind == "var":
        return f"V({nets[ast[1]]})"
    if kind == "neg":
        return f"(-{to_spice(ast[1], nets)})"
    return f"({to_spice(ast[2], nets)} {ast[1]} {to_spice(ast[3], nets)})"


def has_division(ast: Ast) -> bool:
    kind = ast[0]
    if kind == "bin":
        return ast[1] == "/" or has_division(ast[2]) or has_division(ast[3])
    if kind == "neg":
        return has_division(ast[1])
    return False


def evaluate(ast: Ast, env: dict[str, float]) -> float:
    """Evaluate with plain floats. Used only to pre-check divisors, never for results."""
    kind = ast[0]
    if kind == "num":
        return ast[1]
    if kind == "var":
        return env[ast[1]]
    if kind == "neg":
        return -evaluate(ast[1], env)
    left, right = evaluate(ast[2], env), evaluate(ast[3], env)
    op = ast[1]
    if op == "+":
        return left + right
    if op == "-":
        return left - right
    if op == "*":
        return left * right
    if right == 0:
        raise ZeroDivisionError("division by zero")
    return left / right
