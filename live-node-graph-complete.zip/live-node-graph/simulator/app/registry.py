"""Node registry: the single place that defines what each node type does on the backend.

To add a node type, add one ``NodeSpec`` here (and one entry in the frontend registry,
``frontend/src/nodeRegistry.ts``). Nothing else in the simulator knows about node types.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Any, Callable, Mapping

from . import formula

NUMBER_RE = re.compile(r"^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$")

# net names for the wires feeding each input, e.g. {"a": "n1", "b": "n2"}
Nets = Mapping[str, str]
Data = Mapping[str, Any]


@dataclass(frozen=True)
class NodeSpec:
    inputs: tuple[str, ...]
    has_output: bool
    # element name (e.g. "B3"), output net, input nets, node data -> one netlist line
    netlist: Callable[[int, str, Nets, Data], str] | None = None
    # static check of the node's own data; returns an error message or None
    validate: Callable[[Data], str | None] = lambda data: None
    # for nodes that can fail depending on *values* (division): called with the input
    # values once they are known; returns an error message or None
    guard: Callable[[Data, Mapping[str, float]], str | None] | None = None


def _number_value(data: Data) -> float | None:
    raw = data.get("value")
    if isinstance(raw, bool):
        return None
    if isinstance(raw, (int, float)):
        value = float(raw)
    elif isinstance(raw, str) and NUMBER_RE.match(raw.strip()):
        value = float(raw.strip())
    else:
        return None
    return value if math.isfinite(value) else None


def _validate_number(data: Data) -> str | None:
    return None if _number_value(data) is not None else "value must be a finite number"


def _validate_formula(data: Data) -> str | None:
    try:
        formula.parse(data.get("expr", ""))
    except formula.FormulaError as exc:
        return str(exc)
    return None


def _guard_divide(data: Data, values: Mapping[str, float]) -> str | None:
    return "division by zero" if values["b"] == 0 else None


def _guard_formula(data: Data, values: Mapping[str, float]) -> str | None:
    ast = formula.parse(data["expr"])
    if not formula.has_division(ast):
        return None
    try:
        formula.evaluate(ast, dict(values))
    except ZeroDivisionError:
        return "division by zero in expression"
    return None


def _binary(symbol: str) -> Callable[[int, str, Nets, Data], str]:
    return lambda el, out, ins, data: f"B{el} {out} 0 V = V({ins['a']}) {symbol} V({ins['b']})"


REGISTRY: dict[str, NodeSpec] = {
    "number": NodeSpec(
        inputs=(),
        has_output=True,
        netlist=lambda el, out, ins, data: f"V{el} {out} 0 DC {_number_value(data)!r}",
        validate=_validate_number,
    ),
    "add": NodeSpec(("a", "b"), True, _binary("+")),
    "multiply": NodeSpec(("a", "b"), True, _binary("*")),
    "divide": NodeSpec(("a", "b"), True, _binary("/"), guard=_guard_divide),
    "formula": NodeSpec(
        inputs=("a", "b"),
        has_output=True,
        netlist=lambda el, out, ins, data: (
            f"B{el} {out} 0 V = {formula.to_spice(formula.parse(data['expr']), ins)}"
        ),
        validate=_validate_formula,
        guard=_guard_formula,
    ),
    "display": NodeSpec(("x",), False),
}
