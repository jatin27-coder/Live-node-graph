"""Runs ngspice in batch mode and reads the operating point back from its raw file."""
from __future__ import annotations

import asyncio
import os
import re
import struct
import tempfile
from pathlib import Path

NGSPICE_BIN = os.environ.get("NGSPICE_BIN", "ngspice")
TIMEOUT_S = float(os.environ.get("NGSPICE_TIMEOUT", "5"))
MAX_PARALLEL = int(os.environ.get("NGSPICE_PARALLEL", "4"))

_slots: asyncio.Semaphore | None = None
_ELEMENT = re.compile(r"\b([VB])(\d+)\b", re.IGNORECASE)


class SolverTimeout(Exception):
    """ngspice did not finish in time and was killed."""


class SolverFailed(Exception):
    """ngspice exited with an error or produced no result."""

    def __init__(self, message: str, elements: list[str]):
        super().__init__(message)
        self.message = message
        self.elements = elements  # netlist element names mentioned in ngspice's output


def parse_rawfile(data: bytes) -> dict[str, float]:
    """Parse a binary ngspice rawfile holding one operating point -> {'v(n1)': 2.0, ...}."""
    head, sep, body = data.partition(b"Binary:\n")
    if not sep:
        raise SolverFailed("ngspice produced no binary result", [])
    text = head.decode("ascii", "replace")
    n_vars = int(re.search(r"No\. Variables:\s*(\d+)", text).group(1))  # type: ignore[union-attr]
    n_points = int(re.search(r"No\. Points:\s*(\d+)", text).group(1))  # type: ignore[union-attr]
    names = re.findall(r"^\t\d+\t(\S+)\t", text.split("Variables:", 1)[1], re.MULTILINE)
    if n_points < 1 or len(names) != n_vars or len(body) < 8 * n_vars:
        raise SolverFailed("ngspice result file is incomplete", [])
    values = struct.unpack(f"<{n_vars}d", body[: 8 * n_vars])
    return {name.lower(): value for name, value in zip(names, values)}


def _failure(log: str, code: int | None) -> SolverFailed:
    interesting = [ln.strip() for ln in log.splitlines() if re.search(r"error|fatal|singular|fail", ln, re.I)]
    message = interesting[0] if interesting else f"ngspice exited with code {code}"
    elements = list(dict.fromkeys(m.group(1).upper() + m.group(2) for ln in interesting for m in _ELEMENT.finditer(ln)))
    return SolverFailed(message[:300], elements)


async def run(netlist: str) -> dict[str, float]:
    """Run ``netlist`` and return {'v(net)': value}. Raises SolverTimeout / SolverFailed."""
    global _slots
    if _slots is None:
        _slots = asyncio.Semaphore(MAX_PARALLEL)
    async with _slots:
        with tempfile.TemporaryDirectory(prefix="ngspice-") as tmp:
            work = Path(tmp)
            (work / "circuit.cir").write_text(netlist)
            proc = await asyncio.create_subprocess_exec(
                NGSPICE_BIN, "-n", "-b", "-r", "out.raw", "-o", "out.log", "circuit.cir",
                cwd=tmp,
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                env={"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "HOME": tmp},
            )
            try:
                stdout, _ = await asyncio.wait_for(proc.communicate(), TIMEOUT_S)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                raise SolverTimeout(f"ngspice did not finish within {TIMEOUT_S:g}s") from None
            log = stdout.decode("utf-8", "replace")
            log_file = work / "out.log"
            if log_file.exists():
                log += "\n" + log_file.read_text(errors="replace")
            raw = work / "out.raw"
            if proc.returncode != 0 or not raw.exists():
                raise _failure(log, proc.returncode)
            try:
                return parse_rawfile(raw.read_bytes())
            except SolverFailed as exc:
                raise _failure(log, proc.returncode) if not exc.elements and "rror" in log else exc
