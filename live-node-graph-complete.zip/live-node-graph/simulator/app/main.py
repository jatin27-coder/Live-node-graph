"""FastAPI service: POST /simulate runs a graph through ngspice."""
from __future__ import annotations

import logging
from typing import Any

from fastapi import FastAPI
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from . import engine, ngspice
from .netlist import UnsafeNetlist

log = logging.getLogger("simulator")
app = FastAPI(title="Live graph simulator")


class NodeIn(BaseModel):
    id: str = Field(min_length=1, max_length=64)
    type: str = Field(max_length=32)
    data: dict[str, Any] = Field(default_factory=dict)


class EdgeIn(BaseModel):
    source: str
    target: str
    sourceHandle: str | None = None
    targetHandle: str | None = None


class GraphIn(BaseModel):
    nodes: list[NodeIn] = Field(max_length=500)
    edges: list[EdgeIn] = Field(max_length=2000)
    revision: int | str | None = None  # echoed back so clients can discard stale answers


def _error(status: int, code: str, message: str, revision: Any) -> JSONResponse:
    return JSONResponse(status_code=status, content={"error": {"code": code, "message": message}, "revision": revision})


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/simulate")
async def simulate(graph: GraphIn):
    try:
        results = await engine.evaluate(
            [n.model_dump() for n in graph.nodes], [e.model_dump() for e in graph.edges]
        )
    except engine.GraphError as exc:
        return _error(422, "bad_graph", str(exc), graph.revision)
    except ngspice.SolverTimeout as exc:
        return _error(504, "solver_timeout", str(exc), graph.revision)
    except (ngspice.SolverFailed, UnsafeNetlist, FileNotFoundError) as exc:
        log.exception("solver failure")
        return _error(502, "solver_failed", str(exc), graph.revision)
    return {"revision": graph.revision, "nodes": {nid: r.to_json() for nid, r in results.items()}}
