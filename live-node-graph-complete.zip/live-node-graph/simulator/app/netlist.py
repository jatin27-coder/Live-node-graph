"""Turns the (already validated) part of a graph into an ngspice netlist."""
from __future__ import annotations

import re
from typing import Iterable

# Every line we emit must match one of these. This is a second line of defence behind
# the formula parser: whatever happens upstream, nothing else can reach ngspice.
_SAFE_LINES = (
    re.compile(r"^\* live node graph$"),
    re.compile(r"^V\d+ n\d+ 0 DC [-+0-9.eE]+$"),
    re.compile(r"^B\d+ n\d+ 0 V = [-+*/() 0-9.eEV n]+$"),
    re.compile(r"^\.op$"),
    re.compile(r"^\.end$"),
)


class UnsafeNetlist(Exception):
    pass


def assemble(lines: Iterable[str]) -> str:
    body = ["* live node graph", *lines, ".op", ".end"]
    for line in body:
        if not any(p.match(line) for p in _SAFE_LINES):
            raise UnsafeNetlist(f"refusing to emit netlist line: {line!r}")
    return "\n".join(body) + "\n"
