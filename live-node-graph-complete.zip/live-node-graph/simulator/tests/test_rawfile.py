import struct
import unittest

from app.ngspice import SolverFailed, parse_rawfile


def raw(names, values):
    head = (
        "Title: live node graph\nDate: Sat Oct 10 07:58:00  2026\nPlotname: Operating Point\nFlags: real\n"
        f"No. Variables: {len(names)}\nNo. Points: 1\nVariables:\n"
        + "".join(f"\t{i}\t{n}\tvoltage\n" for i, n in enumerate(names))
        + "Binary:\n"
    )
    return head.encode() + struct.pack(f"<{len(values)}d", *values)


class RawfileParsing(unittest.TestCase):
    def test_reads_operating_point(self):
        out = parse_rawfile(raw(["v(n0)", "V(n1)", "i(v0)"], [2.0, 5.0, -1e-3]))
        self.assertEqual(out, {"v(n0)": 2.0, "v(n1)": 5.0, "i(v0)": -1e-3})

    def test_truncated_file_is_a_solver_failure(self):
        with self.assertRaises(SolverFailed):
            parse_rawfile(raw(["v(n0)", "v(n1)"], [1.0, 2.0])[:-4])

    def test_no_binary_section(self):
        with self.assertRaises(SolverFailed):
            parse_rawfile(b"garbage")


if __name__ == "__main__":
    unittest.main()
