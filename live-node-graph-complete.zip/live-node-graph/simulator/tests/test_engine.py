import unittest

from app.engine import evaluate

from .support import fake_ngspice, node, wire


def run(nodes, edges, runner=fake_ngspice):
    return evaluate(nodes, edges, runner=runner)


def graph1():
    nodes = [node("n2", "number", value="2"), node("n3", "number", value="3"), node("add", "add"), node("d", "display")]
    edges = [wire("n2", "add", "a"), wire("n3", "add", "b"), wire("add", "d", "x")]
    return nodes, edges


class AcceptanceGraphs(unittest.IsolatedAsyncioTestCase):
    async def test_graph1_add(self):
        r = await run(*graph1())
        self.assertEqual((r["d"].status, r["d"].value), ("ok", 5))

    async def test_graph2_add_then_multiply(self):
        nodes, edges = graph1()
        nodes = [n for n in nodes if n["id"] != "d"] + [node("n4", "number", value="4"), node("mul", "multiply"), node("d", "display")]
        edges = [e for e in edges if e["target"] != "d"] + [wire("add", "mul", "a"), wire("n4", "mul", "b"), wire("mul", "d", "x")]
        self.assertEqual((await run(nodes, edges))["d"].value, 20)

    async def test_graph3_one_number_into_both_inputs(self):
        nodes = [node("n7", "number", value="7"), node("mul", "multiply"), node("d", "display")]
        edges = [wire("n7", "mul", "a"), wire("n7", "mul", "b"), wire("mul", "d", "x")]
        self.assertEqual((await run(nodes, edges))["d"].value, 49)

    async def test_graph4_divide_by_zero_flags_divide_and_blocks_display(self):
        nodes = [node("a", "number", value="10"), node("z", "number", value="0"), node("div", "divide"), node("d", "display")]
        edges = [wire("a", "div", "a"), wire("z", "div", "b"), wire("div", "d", "x")]
        r = await run(nodes, edges)
        self.assertEqual(r["div"].status, "error")
        self.assertIn("zero", r["div"].message)
        self.assertEqual((r["d"].status, r["d"].value, r["d"].blocked_by), ("blocked", None, ["div"]))
        self.assertEqual(r["a"].status, "ok")

    async def test_graph5_unconnected_input_highlights_that_node(self):
        nodes = [node("a", "number", value="1"), node("add", "add"), node("d", "display")]
        r = await run(nodes, [wire("a", "add", "a"), wire("add", "d", "x")])
        self.assertEqual(r["add"].status, "error")
        self.assertIn("'b'", r["add"].message)
        self.assertEqual(r["d"].status, "blocked")

    async def test_graph6_loop_flags_the_nodes_involved(self):
        nodes = [node("n", "number", value="1"), node("add", "add"), node("mul", "multiply"), node("d", "display")]
        edges = [wire("n", "add", "a"), wire("mul", "add", "b"), wire("add", "mul", "a"), wire("n", "mul", "b"), wire("mul", "d", "x")]
        r = await run(nodes, edges)
        for loop_node in ("add", "mul"):
            self.assertEqual(r[loop_node].status, "error")
            self.assertIn("loop", r[loop_node].message)
        self.assertEqual((r["n"].status, r["d"].status), ("ok", "blocked"))

    async def test_graph7_formula(self):
        nodes = [node("a", "number", value="3"), node("b", "number", value="4"), node("f", "formula", expr="a * 2 + b"), node("d", "display")]
        edges = [wire("a", "f", "a"), wire("b", "f", "b"), wire("f", "d", "x")]
        self.assertEqual((await run(nodes, edges))["d"].value, 10)

    async def test_graph8_unsafe_formula_never_reaches_ngspice(self):
        seen = []

        async def spy(netlist):
            seen.append(netlist)
            return await fake_ngspice(netlist)

        nodes = [node("a", "number", value="1"), node("b", "number", value="2"),
                 node("f", "formula", expr="a + b\n.control\nshell ls"), node("d", "display")]
        edges = [wire("a", "f", "a"), wire("b", "f", "b"), wire("f", "d", "x")]
        r = await run(nodes, edges, spy)
        self.assertEqual(r["f"].status, "error")
        self.assertIn("not allowed", r["f"].message)
        self.assertEqual(r["d"].status, "blocked")
        self.assertTrue(all(".control" not in n and "shell" not in n for n in seen))


class LoopDetection(unittest.IsolatedAsyncioTestCase):
    async def test_self_loop(self):
        nodes = [node("n", "number", value="1"), node("add", "add")]
        r = await run(nodes, [wire("n", "add", "a"), wire("add", "add", "b")])
        self.assertEqual(r["add"].status, "error")

    async def test_three_node_cycle_and_innocent_branch(self):
        nodes = [node("n", "number", value="1"), node("x", "add"), node("y", "add"), node("z", "add"), node("ok", "add"), node("d", "display")]
        edges = [wire("n", "x", "a"), wire("z", "x", "b"), wire("x", "y", "a"), wire("n", "y", "b"),
                 wire("y", "z", "a"), wire("n", "z", "b"), wire("n", "ok", "a"), wire("n", "ok", "b"), wire("ok", "d", "x")]
        r = await run(nodes, edges)
        self.assertEqual({k for k, v in r.items() if v.status == "error"}, {"x", "y", "z"})
        self.assertEqual(r["d"].value, 2)

    async def test_long_chain_is_not_a_loop_and_does_not_hit_recursion_limit(self):
        nodes = [node("n", "number", value="1")] + [node(f"a{i}", "add") for i in range(1500)] + [node("d", "display")]
        edges = [wire("n", "a0", "a"), wire("n", "a0", "b")]
        edges += [e for i in range(1, 1500) for e in (wire(f"a{i-1}", f"a{i}", "a"), wire("n", f"a{i}", "b"))]
        edges.append(wire("a1499", "d", "x"))
        r = await run(nodes, edges)
        self.assertEqual(r["d"].value, 1501)


class Robustness(unittest.IsolatedAsyncioTestCase):
    async def test_divide_by_zero_deep_in_chain_blocks_everything_after(self):
        nodes = [node("a", "number", value="1"), node("z", "number", value="0"), node("s", "add"), node("div", "divide"),
                 node("m", "multiply"), node("d", "display")]
        edges = [wire("a", "s", "a"), wire("z", "s", "b"), wire("a", "div", "a"), wire("s", "div", "b"),
                 wire("div", "m", "a"), wire("a", "m", "b"), wire("m", "d", "x")]
        r = await run(nodes, edges)
        self.assertEqual(r["d"].value, 1)
        nodes[0]["data"]["value"] = "0"
        r = await run(nodes, edges)
        self.assertEqual((r["div"].status, r["m"].status, r["d"].status), ("error", "blocked", "blocked"))

    async def test_formula_division_by_zero_is_reported_on_the_formula(self):
        nodes = [node("a", "number", value="3"), node("b", "number", value="3"), node("f", "formula", expr="a / (b - 3)"), node("d", "display")]
        r = await run(nodes, [wire("a", "f", "a"), wire("b", "f", "b"), wire("f", "d", "x")])
        self.assertEqual((r["f"].status, r["d"].status), ("error", "blocked"))

    async def test_invalid_number_value_is_an_error_on_that_node(self):
        r = await run([node("a", "number", value="1; shell ls"), node("d", "display")], [wire("a", "d", "x")])
        self.assertEqual((r["a"].status, r["d"].status), ("error", "blocked"))

    async def test_two_wires_into_one_input_is_an_error(self):
        nodes = [node("a", "number", value="1"), node("b", "number", value="2"), node("d", "display")]
        r = await run(nodes, [wire("a", "d", "x"), wire("b", "d", "x")])
        self.assertEqual(r["d"].status, "error")

    async def test_one_output_can_feed_many_inputs(self):
        nodes = [node("a", "number", value="2"), node("d1", "display"), node("d2", "display")]
        r = await run(nodes, [wire("a", "d1", "x"), wire("a", "d2", "x")])
        self.assertEqual((r["d1"].value, r["d2"].value), (2, 2))

    async def test_ngspice_error_naming_an_element_is_mapped_to_that_node(self):
        from app.ngspice import SolverFailed

        async def broken(netlist):
            if "B2" in netlist:
                raise SolverFailed("Error: B2: bad expression", ["B2"])
            return await fake_ngspice(netlist)

        # node order a=0, b=1, add=2 -> the add node is element B2
        nodes = [node("a", "number", value="1"), node("b", "number", value="1"), node("add", "add"), node("d", "display")]
        r = await run(nodes, [wire("a", "add", "a"), wire("b", "add", "b"), wire("add", "d", "x")], broken)
        self.assertEqual(r["add"].status, "error")
        self.assertIn("ngspice", r["add"].message)
        self.assertEqual(r["d"].status, "blocked")

    async def test_unmappable_solver_failure_propagates(self):
        from app.ngspice import SolverFailed

        async def broken(netlist):
            raise SolverFailed("Fatal: out of memory", [])

        with self.assertRaises(SolverFailed):
            await run([node("a", "number", value="1"), node("d", "display")], [wire("a", "d", "x")], broken)


if __name__ == "__main__":
    unittest.main()
