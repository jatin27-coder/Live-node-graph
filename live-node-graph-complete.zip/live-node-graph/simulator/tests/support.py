"""Test helpers: a tiny stand-in for ngspice so the suite runs without the binary.

``fake_ngspice`` reads the netlist the engine produced and solves it, so the tests still
exercise netlist generation end to end. ``test_ngspice_integration.py`` runs real graphs
against the real binary when it is installed (it is, inside the Docker image).
"""
import re


def node(id, type, **data):
    return {"id": id, "type": type, "data": data}


def wire(source, target, handle):
    return {"source": source, "target": target, "sourceHandle": "out", "targetHandle": handle}


async def fake_ngspice(netlist: str) -> dict[str, float]:
    lines = netlist.strip().splitlines()
    assert lines[-1] == ".end" and lines[-2] == ".op"
    pending = lines[1:-2]
    values: dict[str, float] = {}
    for _ in range(len(pending) + 1):
        for ln in list(pending):
            if ln.startswith("V"):
                _, net, _, _, value = ln.split()
                values[net] = float(value)
                pending.remove(ln)
            else:
                net, expr = ln.split()[1], ln.split("V = ", 1)[1]
                refs = re.findall(r"V\((n\d+)\)", expr)
                if all(r in values for r in refs):
                    py = re.sub(r"V\((n\d+)\)", lambda m: repr(values[m.group(1)]), expr)
                    try:
                        values[net] = eval(py, {"__builtins__": {}})  # noqa: S307 (test only; netlist is generated)
                    except ZeroDivisionError:
                        values[net] = float("inf")
                    pending.remove(ln)
    assert not pending, f"netlist has unresolved lines: {pending}"
    return {f"v({k})": v for k, v in values.items()}
