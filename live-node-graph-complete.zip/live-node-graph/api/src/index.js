import { createApp } from './app.js';
import { createMongoStore } from './store.js';
import { createSimulatorClient } from './simulator.js';

const app = createApp({
  store: createMongoStore({ url: process.env.MONGO_URL ?? 'mongodb://mongo:27017' }),
  simulator: createSimulatorClient({
    baseUrl: process.env.SIMULATOR_URL ?? 'http://simulator:8000',
    timeoutMs: Number(process.env.SIMULATOR_TIMEOUT_MS ?? 8000),
  }),
});

const port = Number(process.env.PORT ?? 3000);
app.listen(port, () => console.log(`api listening on :${port}`));
