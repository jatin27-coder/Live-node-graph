import express from 'express';
import { cleanGraph, cleanName, ValidationError } from './validate.js';

/** Builds the Express app. Dependencies are injected so tests can use fakes. */
export function createApp({ store, simulator }) {
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', async (_req, res) => {
    const database = await store.ping().then(() => true, () => false);
    res.json({ status: 'ok', database });
  });

  // The editor calls this on every change. If the browser cancels the request (because a newer edit
  // superseded it) we cancel the call to the simulator too.
  app.post('/api/simulate', async (req, res, next) => {
    try {
      const graph = cleanGraph(req.body);
      const ctrl = new AbortController();
      res.on('close', () => { if (!res.writableEnded) ctrl.abort(); });
      const { status, body } = await simulator.simulate(graph, req.body.revision ?? null, ctrl.signal);
      if (!res.writableEnded && !res.destroyed) res.status(status).json(body);
    } catch (err) {
      next(err);
    }
  });

  app.get('/api/graphs', async (_req, res, next) => {
    try { res.json(await store.list()); } catch (err) { next(err); }
  });

  app.get('/api/graphs/:name', async (req, res, next) => {
    try {
      const doc = await store.get(cleanName(req.params.name));
      if (!doc) return res.status(404).json({ error: { code: 'not_found', message: 'No saved graph with that name.' } });
      res.json(doc);
    } catch (err) { next(err); }
  });

  app.delete('/api/graphs/:name', async (req, res, next) => {
    try {
      const name = cleanName(req.params.name);
      const deleted = await store.delete(name);
      if (!deleted) return res.status(404).json({ error: { code: 'not_found', message: 'No saved graph with that name.' } });
      res.json({ name, deleted: true });
    } catch (err) { next(err); }
  });

  app.put('/api/graphs/:name', async (req, res, next) => {
    try {
      const name = cleanName(req.params.name);
      res.json(await store.put(name, cleanGraph(req.body, { requirePositions: true })));
    } catch (err) { next(err); }
  });

  app.use((err, _req, res, _next) => {
    if (err instanceof ValidationError) return res.status(400).json({ error: { code: 'bad_request', message: err.message } });
    if (err?.type === 'entity.parse.failed' || err?.type === 'entity.too.large') return res.status(400).json({ error: { code: 'bad_request', message: 'Invalid JSON body.' } });
    if (err?.code === 'database_unavailable') return res.status(503).json({ error: { code: 'database_unavailable', message: err.message } });
    console.error(err);
    res.status(500).json({ error: { code: 'internal', message: 'Unexpected server error.' } });
  });

  return app;
}
