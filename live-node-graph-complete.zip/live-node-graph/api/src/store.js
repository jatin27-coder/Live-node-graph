import { MongoClient } from 'mongodb';

/** MongoDB-backed graph store. Connects lazily and reconnects on demand, so a database that is
 *  slow to start (or restarts) only affects save/load, never the live simulation. */
export function createMongoStore({ url, dbName = 'livegraph' }) {
  let client = null;
  let connecting = null;

  async function collection() {
    if (!client) {
      connecting ??= (async () => {
        const c = new MongoClient(url, { serverSelectionTimeoutMS: 2000 });
        await c.connect();
        await c.db(dbName).collection('graphs').createIndex({ name: 1 }, { unique: true });
        client = c;
      })().finally(() => { connecting = null; });
      await connecting;
    }
    return client.db(dbName).collection('graphs');
  }

  const guard = async (fn) => {
    try {
      return await fn(await collection());
    } catch (err) {
      if (err?.name?.startsWith('Mongo') || err?.code === 'ECONNREFUSED') {
        client?.close().catch(() => {});
        client = null;
        const e = new Error('Database is not reachable');
        e.code = 'database_unavailable';
        throw e;
      }
      throw err;
    }
  };

  return {
    ping: () => guard((c) => c.estimatedDocumentCount().then(() => true)),
    list: () => guard((c) => c.find({}, { projection: { _id: 0, name: 1, updatedAt: 1 } }).sort({ updatedAt: -1 }).limit(100).toArray()),
    get: (name) => guard((c) => c.findOne({ name }, { projection: { _id: 0 } })),
    put: (name, graph) =>
      guard(async (c) => {
        const doc = { name, nodes: graph.nodes, edges: graph.edges, updatedAt: new Date().toISOString() };
        await c.replaceOne({ name }, doc, { upsert: true });
        return { name, updatedAt: doc.updatedAt };
      }),
  };
}
