// Client for the Python simulation service. Never throws: every failure becomes a structured error
// the frontend can show ("service down", "timed out", ...), so the rest of the API keeps working.

export function createSimulatorClient({ baseUrl, timeoutMs = 8000, fetchImpl = fetch }) {
  return {
    /** @returns {Promise<{status:number, body:object}>} */
    async simulate(graph, revision, clientSignal) {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(new Error('timeout')), timeoutMs);
      const onClientAbort = () => ctrl.abort(new Error('client-gone'));
      clientSignal?.addEventListener('abort', onClientAbort, { once: true });
      try {
        const res = await fetchImpl(`${baseUrl}/simulate`, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ ...graph, revision }),
          signal: ctrl.signal,
        });
        let body;
        try {
          body = await res.json();
        } catch {
          return fail(502, 'simulator_bad_response', 'The simulation service sent an unreadable response.', revision);
        }
        if (res.ok) return { status: 200, body };
        if (body?.error) return { status: res.status, body: { ...body, revision } };
        // FastAPI validation errors etc.
        return fail(res.status === 422 ? 400 : 502, 'simulator_rejected', 'The simulation service rejected the graph.', revision);
      } catch (err) {
        if (ctrl.signal.aborted && ctrl.signal.reason?.message === 'client-gone') return fail(499, 'client_gone', 'Request cancelled.', revision);
        if (ctrl.signal.aborted) return fail(504, 'simulator_timeout', `The simulation service did not answer within ${timeoutMs / 1000}s.`, revision);
        return fail(503, 'simulator_unavailable', 'The simulation service is not reachable.', revision);
      } finally {
        clearTimeout(timer);
        clientSignal?.removeEventListener('abort', onClientAbort);
      }
    },
  };
}

const fail = (status, code, message, revision) => ({ status, body: { error: { code, message }, revision } });
