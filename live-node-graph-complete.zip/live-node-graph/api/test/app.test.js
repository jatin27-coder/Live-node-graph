import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/app.js';

async function startServer(t, app) {
  const server = app.listen(0, '127.0.0.1');
  await new Promise((resolve) => server.once('listening', resolve));
  t.after(() => new Promise((resolve, reject) => server.close((err) => err ? reject(err) : resolve())));
  return `http://127.0.0.1:${server.address().port}`;
}

test('deletes a saved graph and returns not found for a missing graph', async (t) => {
  const saved = new Set(['my graph']);
  const app = createApp({
    store: { delete: async (name) => saved.delete(name), ping: async () => true },
    simulator: {},
  });
  const baseUrl = await startServer(t, app);

  const deleted = await fetch(`${baseUrl}/api/graphs/my%20graph`, { method: 'DELETE' });
  assert.equal(deleted.status, 200);
  assert.deepEqual(await deleted.json(), { name: 'my graph', deleted: true });
  assert.equal(saved.has('my graph'), false);

  const missing = await fetch(`${baseUrl}/api/graphs/my%20graph`, { method: 'DELETE' });
  assert.equal(missing.status, 404);
  assert.equal((await missing.json()).error.code, 'not_found');
});