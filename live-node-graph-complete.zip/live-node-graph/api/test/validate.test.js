import test from 'node:test';
import assert from 'node:assert/strict';
import { cleanGraph, cleanName, ValidationError } from '../src/validate.js';

const node = (extra = {}) => ({ id: 'n1', type: 'number', position: { x: 1, y: 2 }, data: { value: '5' }, ...extra });

test('keeps only whitelisted fields and drops runtime junk', () => {
  const g = cleanGraph({ nodes: [node({ selected: true, measured: { width: 1 } })], edges: [{ id: 'e', source: 'n1', target: 'n2', targetHandle: 'a', extra: 1 }] }, { requirePositions: true });
  assert.deepEqual(g.nodes[0], { id: 'n1', type: 'number', data: { value: '5' }, position: { x: 1, y: 2 } });
  assert.deepEqual(Object.keys(g.edges[0]).sort(), ['id', 'source', 'sourceHandle', 'target', 'targetHandle']);
});

test('rejects malformed graphs', () => {
  assert.throws(() => cleanGraph(null), ValidationError);
  assert.throws(() => cleanGraph({ nodes: 'x', edges: [] }), ValidationError);
  assert.throws(() => cleanGraph({ nodes: [node({ data: { value: { nested: 1 } } })], edges: [] }), ValidationError);
  assert.throws(() => cleanGraph({ nodes: [node({ position: undefined })], edges: [] }, { requirePositions: true }), ValidationError);
  assert.throws(() => cleanGraph({ nodes: Array(501).fill(node()), edges: [] }), ValidationError);
});

test('graph names are restricted', () => {
  assert.equal(cleanName('my graph-1'), 'my graph-1');
  for (const bad of ['', '../x', '$where', 'a'.repeat(61), 5]) assert.throws(() => cleanName(bad), ValidationError);
});
