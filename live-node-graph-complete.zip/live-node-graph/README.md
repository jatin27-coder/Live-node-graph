# Live Node Graph

A browser node editor whose graph is executed by ngspice. Every edit re-runs the graph and the canvas stays in sync.

## Run it

```bash
docker compose up --build        # then open http://localhost:8080
```

Tests (no ngspice needed for most; the Docker image has it, so the real-ngspice tests run there):

```bash
docker compose run --rm simulator python -m unittest discover -s . -t .   # graphs 1-3 and 7, loops, unsafe formula, hang
cd api && npm test            # validation, simulator client timeouts/cancellation
cd frontend && npm test       # live-sync rules: debounce, stale responses, retry
```

## Architecture

```
 Browser (React + React Flow)  --/api-->  Node API (Express)  ---->  Python service (FastAPI)  --> ngspice -b
   nginx serves it, proxies /api            |  validates, times out,                 builds netlist, validates graph
                                            |  cancels, never crashes if downstream is down
                                            +----> MongoDB  (save / load only)
```

The browser only talks to the Node API. Only the Python service runs ngspice. Mongo is used for save/load only, so a database outage never affects the live simulation.

## Graph to netlist, and loops

1. Each node gets an index `i`; its output net is `n<i>`, its element `V<i>`/`B<i>`. Wires put an output and an input on the same net, so an input's net is just its source's output net. Node ids from the UI never reach the netlist.
2. Lines come from the provided mapping (`simulator/app/registry.py`). The netlist ends with `.op` / `.end`; ngspice runs with `-b -r`, and the operating point is read from the binary raw file (full double precision).
3. Before ngspice, each node is checked on its own (bad number, bad formula, input unconnected or wired twice). Loops are found with an iterative Tarjan strongly-connected-components pass: every node in a component of size > 1 (or with a self-wire) is flagged. Everything downstream of a flagged node is **blocked**.
4. Divide (and Formula with `/`) can fail depending on *values*. They are added to the netlist only after their inputs are known and the divisor was checked, so division by zero lands on the right node (cost: one extra ngspice run per level of chained divides).

## Step 5

- **Fast edits.** The client debounces 150 ms, keeps one request in flight, and aborts the previous one on every edit. Each request carries a revision number and the server echoes it; a response is shown only if it is for the latest revision *and* the same graph signature is on the canvas, so out-of-order answers are dropped. Between an edit and its result, nodes show "…", never an old value. (`frontend/src/liveSync.ts`, unit-tested.) The API forwards the abort to the Python service.
- **Errors on the right node.** Pre-checks (unconnected inputs, loops, bad data, divide by zero) run before ngspice and name the node. If ngspice itself errors, element names in its output (`B3`) are mapped back to nodes. Dependants show **blocked**, not a stale value.
- **ngspice misbehaves.** ngspice has a 5 s timeout and is killed on expiry; the API has its own 8 s timeout and turns "service down / timeout / crash" into typed errors. The UI shows a banner and auto-retries with backoff (1, 2, 4, 8 s), and any new edit retries immediately. Editing, wiring and save/load keep working throughout.
- **Untrusted formulas.** Formulas are tokenised against a whitelist (numbers, `a`, `b`, `+ - * /`, brackets), parsed into an AST and **re-serialised by us**; the raw text never enters the netlist. A final check requires every netlist line to match a strict pattern, otherwise nothing is sent. Input like `a\n.control\nshell ls` is rejected with a message.

**Known to break:** a long chain of Divide nodes (N levels) needs N+1 ngspice runs, so a very deep chain can exceed the timeout and show as "timed out". An ngspice error that names no element cannot be attributed to a node and is shown as a banner only.

## Adding a node type (e.g. Subtract)

Two entries: `simulator/app/registry.py` (a `NodeSpec`, one netlist line) and `frontend/src/nodeRegistry.ts` (label, input handles, defaults). Palette, rendering, validation, netlist and save/load pick it up from those. Add a test beside the others in `simulator/tests/test_engine.py`.

## What I'd do next

Subtract/Power/Min/Max nodes; a Display history sparkline; batching so an N-deep divide chain needs one run; delete saved graphs; Mongo auth and a lockfile-pinned frontend build; Playwright end-to-end tests for the eight acceptance graphs; undo/redo.

## AI usage note

Claude (Anthropic) was used to scaffold the project, write the first version of the simulator, API and frontend, and draft the tests and this README. I reviewed and ran the code and I can explain and change every file. *(Edit this note to describe your own usage accurately.)*
